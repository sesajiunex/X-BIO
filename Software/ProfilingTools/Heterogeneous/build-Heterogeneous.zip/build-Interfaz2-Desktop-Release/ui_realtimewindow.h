/********************************************************************************
** Form generated from reading UI file 'realtimewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REALTIMEWINDOW_H
#define UI_REALTIMEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_realtimewindow
{
public:
    QWidget *plotWWidget;
    QWidget *plotJWidget;

    void setupUi(QDialog *realtimewindow)
    {
        if (realtimewindow->objectName().isEmpty())
            realtimewindow->setObjectName(QString::fromUtf8("realtimewindow"));
        realtimewindow->resize(1165, 691);
        realtimewindow->setMinimumSize(QSize(1165, 691));
        realtimewindow->setBaseSize(QSize(1165, 691));
        plotWWidget = new QWidget(realtimewindow);
        plotWWidget->setObjectName(QString::fromUtf8("plotWWidget"));
        plotWWidget->setGeometry(QRect(0, 0, 1161, 331));
        plotJWidget = new QWidget(realtimewindow);
        plotJWidget->setObjectName(QString::fromUtf8("plotJWidget"));
        plotJWidget->setGeometry(QRect(0, 360, 1161, 321));

        retranslateUi(realtimewindow);

        QMetaObject::connectSlotsByName(realtimewindow);
    } // setupUi

    void retranslateUi(QDialog *realtimewindow)
    {
        realtimewindow->setWindowTitle(QCoreApplication::translate("realtimewindow", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class realtimewindow: public Ui_realtimewindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REALTIMEWINDOW_H
